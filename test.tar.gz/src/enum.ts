
enum RoleType {
  USER = 'USER',
    DRIVER = "DRIVER",
    OPERATOR = "OPERATOR",
    ADMIN = "ADMIN",
  }
   
  export default RoleType;