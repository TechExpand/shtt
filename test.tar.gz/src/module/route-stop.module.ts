// import { Module } from '@nestjs/common';
// import { TypeOrmModule } from '@nestjs/typeorm';
// import { RoutePointController } from '../web/rest/route-stop.controller';
// import { RoutePointRepositorys } from '../repository/route-stop.repository';
// import { RoutePointService } from '../service/route-stop.service';
// import { JwtService } from '@nestjs/jwt';


// @Module({
//   imports: [TypeOrmModule.forFeature([RoutePointRepositorys,JwtService])],
//   controllers: [RoutePointController],
//   providers: [RoutePointService,JwtService],
//   exports: [RoutePointService,JwtService],
// })
// export class RouteStopModule {}
