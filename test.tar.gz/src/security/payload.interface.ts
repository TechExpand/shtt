export interface Payload {

  id: number;
  username: string;
  role: number;
  authorities?: string[];

}
