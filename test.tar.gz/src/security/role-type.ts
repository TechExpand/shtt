'use strict';

// export enum RoleType {
//   USER = 'USER',
//   ADMIN = 'ADMIN',
//   OPERATOR = 'OPERATOR',
//   DRIVER = 'DRIVER',
// }
