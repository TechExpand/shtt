/* eslint-disable @typescript-eslint/no-unused-vars */
import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, MinLength, MaxLength, Length, Min, Max, Matches } from 'class-validator';
import { BaseDTO } from './base.dto';




/**
 * A PointDTO object.
 */
export class PointDTO extends BaseDTO {

    //     @IsNotEmpty()
    //     @ApiProperty({description: 'name field'})
    // name: string;

    @IsNotEmpty()
    @ApiProperty({ description: 'latitude field' })
    latitude: any;

    @IsNotEmpty()
    @ApiProperty({ description: 'longitude field' })
    longitude: any;

    @ApiProperty({ description: 'street field', required: false })
    address: string;


    @ApiProperty({ description: 'street field', required: false })
    type: string;



    @ApiProperty({ description: 'distance field' })
    routeId?: number;


    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

}
