// import express from "express";

// declare global {
//   namespace Express {
//     interface Request {
//       user?: Record<string,any>,
//       status?: Record<string,any>,
//       set?: Record<string,any>
//     }
//   }
// }